// console.log("connected");

$(document).ready(function () {

    new WOW().init();



    $('.js-wp-2').waypoint(function (direction) {
        $('.js-wp-2').addClass('animated slideInUp');
    }, {
        offset: '70%'
    });

    $('.iphone-btn').delay(2300).animate({
            bottom: "+=-3"
        }, 300),
    $('.iphone-btn').delay(300).animate({
            top: "+=-3"
        }, 100)

    $('.js-wp-3').waypoint(function (direction) {
        $('.js-wp-3').addClass('animated fadeIn');
    }, {
        offset: '70%'
    });

});


// SCROLLING TO THE NEXT ID

$('a[href^="#"]').on('click', function (event) {
    var target = $(this.getAttribute('href'));
    if (target.length) {
        event.preventDefault();
        $('html, body').stop().animate({
            scrollTop: target.offset().top
        }, 1000);
    }
});